import{R as t,r as i}from"./react-5372a523.js";import{h as Q}from"./@babel-09ac47d2.js";var H={exports:{}};/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/(function(n){(function(){var e={}.hasOwnProperty;function o(){for(var c="",a=0;a<arguments.length;a++){var r=arguments[a];r&&(c=s(c,l(r)))}return c}function l(c){if(typeof c=="string"||typeof c=="number")return c;if(typeof c!="object")return"";if(Array.isArray(c))return o.apply(null,c);if(c.toString!==Object.prototype.toString&&!c.toString.toString().includes("[native code]"))return c.toString();var a="";for(var r in c)e.call(c,r)&&c[r]&&(a=s(a,r));return a}function s(c,a){return a?c?c+" "+a:c+a:c}n.exports?(o.default=o,n.exports=o):window.classNames=o})()})(H);var J=H.exports;const T=Q(J);function A(n,e){e===void 0&&(e={});var o=e.insertAt;if(!(!n||typeof document>"u")){var l=document.head||document.getElementsByTagName("head")[0],s=document.createElement("style");s.type="text/css",o==="top"&&l.firstChild?l.insertBefore(s,l.firstChild):l.appendChild(s),s.styleSheet?s.styleSheet.cssText=n:s.appendChild(document.createTextNode(n))}}var Z=`/**
 * @Author Awen
 * @Date 2024/05/25
 * @Email wengaolng@gmail.com
 **/
.index-module_iconBlock__Y1IUb {
  flex: 1;
}
.index-module_dots__2OJFw {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 0;
}
.index-module_dots__2OJFw .dot {
  position: absolute;
  z-index: 10;
  width: 20px;
  height: 20px;
  color: #cedffe;
  background: #3e7cff;
  border: 2px solid #f7f9fb;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  justify-content: center;
  border-radius: 20px;
  cursor: default;
  font-weight: 600;
}
`,U={iconBlock:"index-module_iconBlock__Y1IUb",dots:"index-module_dots__2OJFw"};A(Z);var G=`/**
 * @Author Awen
 * @Date 2024/05/25
 * @Email wengaolng@gmail.com
 **/
.gocaptcha-module_wrapper__Kpdey {
  padding: 12px 16px;
  background: #ffffff;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  box-sizing: border-box;
}
.gocaptcha-module_theme__h-Ytl {
  border: 1px solid rgba(206, 223, 254, 0.5);
  -webkit-border-radius: 8px;
  -moz-border-radius: 8px;
  border-radius: 8px;
  box-shadow: 0 0 20px rgba(100, 100, 100, 0.1);
  -webkit-box-shadow: 0 0 20px rgba(100, 100, 100, 0.1);
  -moz-box-shadow: 0 0 20px rgba(100, 100, 100, 0.1);
}
.gocaptcha-module_header__LjDUC {
  height: 36px;
  width: 100%;
  font-size: 15px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.gocaptcha-module_header__LjDUC span {
  flex: 1;
  padding-right: 5px;
}
.gocaptcha-module_header__LjDUC em {
  padding: 0 3px;
  font-weight: bold;
  color: #3e7cff;
  font-style: normal;
}
.gocaptcha-module_body__KJKNu {
  position: relative;
  width: 100%;
  margin-top: 10px;
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  background: #34383e;
  border-radius: 5px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  overflow: hidden;
}
.gocaptcha-module_picture__LRwbY {
  position: relative;
  z-index: 10;
  width: 100%;
}
.gocaptcha-module_loading__Y-PYK {
  position: absolute;
  z-index: 9;
  top: 50%;
  left: 50%;
  width: 68px;
  height: 68px;
  margin-left: -34px;
  margin-top: -34px;
  line-height: 68px;
  text-align: center;
}
.gocaptcha-module_footer__Ywdpy {
  width: 100%;
  height: 60px;
  color: #34383e;
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  align-items: center;
  padding-top: 15px;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.gocaptcha-module_iconBlock__mVB8B {
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  align-items: center;
}
.gocaptcha-module_iconBlock__mVB8B svg {
  color: #3C3C3C;
  fill: #3C3C3C;
  margin: 0 5px;
  cursor: pointer;
}
.gocaptcha-module_buttonBlock__EZ4vg {
  width: 120px;
  height: 40px;
}
.gocaptcha-module_buttonBlock__EZ4vg button {
  width: 100%;
  height: 40px;
  letter-spacing: 2px;
  text-align: center;
  padding: 9px 15px;
  font-size: 15px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
  display: inline-block;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  color: #fff;
  background-color: #4e87ff;
  border: 1px solid #4e87ff;
  -webkit-appearance: none;
  box-sizing: border-box;
  outline: none;
  margin: 0;
  transition: 0.1s;
  font-weight: 500;
  -moz-user-select: none;
  -webkit-user-select: none;
}
.gocaptcha-module_dragSlideBar__noauW {
  width: 100%;
  height: 100%;
  position: relative;
  touch-action: none;
}
.gocaptcha-module_dragLine__3B9KR {
  position: absolute;
  height: 14px;
  background: #e0e0e0;
  left: 0;
  right: 0;
  top: 50%;
  margin-top: -7px;
  -webkit-border-radius: 7px;
  -moz-border-radius: 7px;
  border-radius: 7px;
}
.gocaptcha-module_dragBlock__bFlwx {
  position: absolute;
  left: 0;
  top: 50%;
  margin-top: -22px;
  width: 82px;
  height: 44px;
  z-index: 10;
  background: #3e7cff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  -webkit-border-radius: 24px;
  -moz-border-radius: 24px;
  border-radius: 24px;
  box-shadow: 0 0 20px rgba(100, 100, 100, 0.35);
  -webkit-box-shadow: 0 0 20px rgba(100, 100, 100, 0.35);
  -moz-box-shadow: 0 0 20px rgba(100, 100, 100, 0.35);
}
.gocaptcha-module_dragBlock__bFlwx {
  color: #ffffff;
  fill: #ffffff;
}
`,d={wrapper:"gocaptcha-module_wrapper__Kpdey",theme:"gocaptcha-module_theme__h-Ytl",header:"gocaptcha-module_header__LjDUC",body:"gocaptcha-module_body__KJKNu",picture:"gocaptcha-module_picture__LRwbY",loading:"gocaptcha-module_loading__Y-PYK",footer:"gocaptcha-module_footer__Ywdpy",iconBlock:"gocaptcha-module_iconBlock__mVB8B",buttonBlock:"gocaptcha-module_buttonBlock__EZ4vg",dragSlideBar:"gocaptcha-module_dragSlideBar__noauW",dragLine:"gocaptcha-module_dragLine__3B9KR",dragBlock:"gocaptcha-module_dragBlock__bFlwx"};A(G);const R=()=>({width:300,height:240,thumbWidth:150,thumbHeight:40,verticalPadding:16,horizontalPadding:12,showTheme:!0}),$=n=>i.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 200 200",width:26,height:26},n),i.createElement("path",{d:`M100.1,189.9C100.1,189.9,100,189.9,100.1,189.9c-49.7,0-90-40.4-90-89.9c0-49.6,40.4-89.9,89.9-89.9
		c49.6,0,89.9,40.4,89.9,89.9c0,18.2-5.4,35.7-15.6,50.7c-1.5,2.1-3.6,3.4-6.1,3.9c-2.5,0.4-5-0.1-7-1.6c-4.2-3-5.3-8.6-2.4-12.9
		c8.1-11.9,12.4-25.7,12.4-40.1c0-39.2-31.9-71.1-71.1-71.1c-39.2,0-71.1,31.9-71.1,71.1c0,39.2,31.9,71.1,71.1,71.1
		c7.7,0,15.3-1.2,22.6-3.6c2.4-0.8,4.9-0.6,7.2,0.5c2.2,1.1,3.9,3.1,4.7,5.5c1.6,4.9-1,10.2-5.9,11.9
		C119.3,188.4,109.8,189.9,100.1,189.9z M73,136.4C73,136.4,73,136.4,73,136.4c-2.5,0-4.9-1-6.7-2.8c-3.7-3.7-3.7-9.6,0-13.3
		L86.7,100L66.4,79.7c-3.7-3.7-3.7-9.6,0-13.3c3.7-3.7,9.6-3.7,13.3,0L100,86.7l20.3-20.3c1.8-1.8,4.1-2.8,6.7-2.8c0,0,0,0,0,0
		c2.5,0,4.9,1,6.7,2.8c1.8,1.8,2.8,4.1,2.8,6.7c0,2.5-1,4.9-2.8,6.7L113.3,100l20.3,20.3c3.7,3.7,3.7,9.6,0,13.3
		c-3.7,3.7-9.6,3.7-13.3,0L100,113.3l-20.3,20.3C77.9,135.4,75.5,136.4,73,136.4z`})),M=n=>i.createElement("svg",Object.assign({width:26,height:26},n,{viewBox:"0 0 200 200",xmlns:"http://www.w3.org/2000/svg"}),i.createElement("path",{d:`M135,149.9c-10.7,7.6-23.2,11.4-36,11.2c-1.7,0-3.4-0.1-5-0.3c-0.7-0.1-1.4-0.2-2-0.3c-1.3-0.2-2.6-0.4-3.9-0.6
	c-0.8-0.2-1.6-0.4-2.3-0.5c-1.2-0.3-2.5-0.6-3.7-1c-0.6-0.2-1.2-0.4-1.7-0.6c-1.4-0.5-2.8-1-4.2-1.5c-0.3-0.1-0.6-0.3-0.9-0.4
	c-1.6-0.7-3.2-1.4-4.7-2.3c-0.1,0-0.1-0.1-0.2-0.1c-5.1-2.9-9.8-6.4-14-10.6c-0.1-0.1-0.1-0.1-0.2-0.2c-1.3-1.3-2.5-2.7-3.7-4.1
	c-0.2-0.3-0.5-0.6-0.7-0.9c-8.4-10.6-13.5-24.1-13.5-38.8h14.3c0.4,0,0.7-0.2,0.9-0.5c0.2-0.3,0.2-0.8,0-1.1L29.5,60.9
	c-0.2-0.3-0.5-0.5-0.9-0.5c-0.4,0-0.7,0.2-0.9,0.5L3.8,97.3c-0.2,0.3-0.2,0.7,0,1.1c0.2,0.3,0.5,0.5,0.9,0.5h14.3
	c0,17.2,5.3,33.2,14.3,46.4c0.1,0.2,0.2,0.4,0.3,0.6c0.9,1.4,2,2.6,3,3.9c0.4,0.5,0.7,1,1.1,1.5c1.5,1.8,3,3.5,4.6,5.2
	c0.2,0.2,0.3,0.3,0.5,0.5c5.4,5.5,11.5,10.1,18.2,13.8c0.2,0.1,0.3,0.2,0.5,0.3c1.9,1,3.9,2,5.9,2.9c0.5,0.2,1,0.5,1.5,0.7
	c1.7,0.7,3.5,1.3,5.2,1.9c0.8,0.3,1.7,0.6,2.5,0.8c1.5,0.5,3.1,0.8,4.7,1.2c1.1,0.2,2.1,0.5,3.2,0.7c0.4,0.1,0.9,0.2,1.3,0.3
	c1.5,0.3,3,0.4,4.5,0.6c0.5,0.1,1.1,0.2,1.6,0.2c2.7,0.3,5.4,0.4,8.1,0.4c16.4,0,32.5-5.1,46.2-14.8c4.4-3.1,5.5-9.2,2.4-13.7
	C145.5,147.8,139.4,146.7,135,149.9 M180.6,98.9c0-17.2-5.3-33.1-14.2-46.3c-0.1-0.2-0.2-0.5-0.4-0.7c-1.1-1.6-2.3-3.1-3.5-4.6
	c-0.1-0.2-0.3-0.4-0.4-0.6c-8.2-10.1-18.5-17.9-30.2-23c-0.3-0.1-0.6-0.3-1-0.4c-1.9-0.8-3.8-1.5-5.7-2.1c-0.7-0.2-1.4-0.5-2.1-0.7
	c-1.7-0.5-3.4-0.9-5.1-1.3c-0.9-0.2-1.9-0.5-2.8-0.7c-0.5-0.1-0.9-0.2-1.4-0.3c-1.3-0.2-2.6-0.3-3.8-0.5c-0.9-0.1-1.8-0.3-2.6-0.3
	c-2.1-0.2-4.3-0.3-6.4-0.3c-0.4,0-0.8-0.1-1.2-0.1c-0.1,0-0.1,0-0.2,0c-16.4,0-32.4,5-46.2,14.8C49,35,48,41.1,51,45.6
	c3.1,4.4,9.1,5.5,13.5,2.4c10.6-7.5,23-11.3,35.7-11.2c1.8,0,3.6,0.1,5.4,0.3c0.6,0.1,1.1,0.1,1.6,0.2c1.5,0.2,2.9,0.4,4.3,0.7
	c0.6,0.1,1.3,0.3,1.9,0.4c1.4,0.3,2.8,0.7,4.2,1.1c0.4,0.1,0.9,0.3,1.3,0.4c1.6,0.5,3.1,1.1,4.6,1.7c0.2,0.1,0.3,0.1,0.5,0.2
	c9,3.9,17,10,23.2,17.6c0,0,0.1,0.1,0.1,0.2c8.7,10.7,14,24.5,14,39.4H147c-0.4,0-0.7,0.2-0.9,0.5c-0.2,0.3-0.2,0.8,0,1.1l24,36.4
	c0.2,0.3,0.5,0.5,0.9,0.5c0.4,0,0.7-0.2,0.9-0.5l23.9-36.4c0.2-0.3,0.2-0.7,0-1.1c-0.2-0.3-0.5-0.5-0.9-0.5L180.6,98.9L180.6,98.9
	L180.6,98.9z`})),K=n=>i.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 100 100",preserveAspectRatio:"xMidYMid",width:84,height:84},n),i.createElement("circle",{cx:"50",cy:"36.8101",r:"10",fill:"#3e7cff"},i.createElement("animate",{attributeName:"cy",dur:"1s",repeatCount:"indefinite",calcMode:"spline",keySplines:"0.45 0 0.9 0.55;0 0.45 0.55 0.9",keyTimes:"0;0.5;1",values:"23;77;23"})));function ee(n){let e=0,o=0;if(n.getBoundingClientRect){const l=n.getBoundingClientRect(),s=document.documentElement;e=l.left+Math.max(s.scrollLeft,document.body.scrollLeft)-s.clientLeft,o=l.top+Math.max(s.scrollTop,document.body.scrollTop)-s.clientTop}else for(;n!==document.body;)e+=n.offsetLeft,o+=n.offsetTop,n=n.offsetParent;return{domX:e,domY:o}}function O(n,e){let o=e.relatedTarget;try{for(;o&&o!==n;)o=o.parentNode}catch(l){console.warn(l)}return o!==n}const te=(n,e)=>{const[o,l]=i.useState([]),s=i.useCallback(u=>{const m=u.currentTarget,C=ee(m),S=u.pageX||u.clientX,f=u.pageY||u.clientY,D=C.domX,X=C.domY,x=S-D,P=f-X,y=parseInt(x.toString()),z=parseInt(P.toString()),v=new Date,_=o.length;return l([...o,{key:v.getTime(),index:_+1,x:y,y:z}]),e.click&&e.click(y,z),u.cancelBubble=!0,u.preventDefault(),!1},[o,e]),c=i.useCallback(u=>(e.confirm&&e.confirm(o,()=>{l([])}),u.cancelBubble=!0,u.preventDefault(),!1),[o,e]),a=i.useCallback(u=>(e.close&&e.close(),l([]),u.cancelBubble=!0,u.preventDefault(),!1),[e]),r=i.useCallback(u=>(e.refresh&&e.refresh(),l([]),u.cancelBubble=!0,u.preventDefault(),!1),[e]),h=i.useCallback(()=>o,[o]);return{setDots:l,getDots:h,clickEvent:s,confirmEvent:c,closeEvent:a,refreshEvent:r}},ne=n=>{const e={...R(),...n.config||{}},o=n.data||{},l=te(o,n.events||{}),s=e.horizontalPadding||0,c=e.verticalPadding||0,a=(e.width||0)+c*2;return t.createElement("div",{className:T(d.wrapper,e.showTheme&&d.theme),style:{width:a+"px",paddingLeft:c+"px",paddingRight:c+"px",paddingTop:s+"px",paddingBottom:s+"px"}},t.createElement("div",{className:d.header},t.createElement("span",null,"请在下图",t.createElement("em",null,"依次"),"点击："),t.createElement("img",{style:{width:e.thumbWidth+"px",height:e.thumbHeight+"px"},src:o.thumb,alt:"..."})),t.createElement("div",{className:d.body},t.createElement("div",{className:d.loading},t.createElement(K,null)),t.createElement("img",{className:d.picture,style:{width:e.width+"px",height:e.height+"px"},src:o.image,alt:"...",onClick:l.clickEvent}),t.createElement("div",{className:U.dots},l.getDots().map(r=>t.createElement("div",{className:"dot",style:{top:r.y-11+"px",left:r.x-11+"px"},key:r.key+"-"+r.index},r.index)))),t.createElement("div",{className:d.footer},t.createElement("div",{className:T(d.iconBlock,U.iconBlock)},t.createElement($,{width:22,height:22,onClick:l.closeEvent}),t.createElement(M,{width:22,height:22,onClick:l.refreshEvent})),t.createElement("div",{className:d.buttonBlock},t.createElement("button",{onClick:l.confirmEvent},"确认"))))};var oe=t.memo(ne),ce=`/**
 * @Author Awen
 * @Date 2024/05/25
 * @Email wengaolng@gmail.com
 **/
.index-module_tile__8pkQD {
  position: absolute;
  z-index: 30;
  cursor: pointer;
}
.index-module_tile__8pkQD img {
  display: block;
  cursor: pointer;
  width: 100%;
  height: 100%;
}
`,le={tile:"index-module_tile__8pkQD"};A(ce);const q=n=>i.createElement("svg",Object.assign({viewBox:"0 0 200 200",xmlns:"http://www.w3.org/2000/svg",width:20,height:20},n),i.createElement("path",{d:`M131.6,116.3c0,0-75.6,0-109.7,0c-9.1,0-16.2-7.4-16.2-16.2c0-9.1,7.4-16.2,16.2-16.2c28.7,0,109.7,0,109.7,0
	s-5.4-5.4-30.4-30.7c-6.4-6.4-6.4-16.7,0-23.1s16.7-6.4,23.1,0l58.4,58.4c6.4,6.4,6.4,16.7,0,23.1c0,0-32.9,32.9-57.9,57.9
	c-6.4,6.4-16.7,6.4-23.1,0c-6.4-6.4-6.4-16.7,0-23.1C121.8,126.2,131.6,116.3,131.6,116.3z`})),ie=()=>({width:300,height:240,thumbWidth:150,thumbHeight:40,verticalPadding:16,horizontalPadding:12,showTheme:!0}),se=(n,e,o,l,s,c)=>{const[a,r]=i.useState(0),[h,u]=i.useState(n.thumbX||0),m=i.useCallback(()=>{r(0),u(0)},[]),C=i.useCallback(x=>{const P=x.touches&&x.touches[0],y=s.current.offsetLeft,z=o.current.offsetWidth,v=s.current.offsetWidth,_=z-v,k=n.thumbX||0,B=l.current.offsetWidth,L=v-B,g=(_-k+L)/_;let E=!1,p=0,F=0;P?p=P.pageX-y:p=x.clientX-y;const w=N=>{E=!0;const V=N.touches&&N.touches[0];let I=0;if(V?I=V.pageX-p:I=N.clientX-p,I>=_){r(_);return}if(I<=0){r(0);return}r(I),F=k+I*g,u(F),e.move&&e.move(F,n.thumbY||0),N.cancelBubble=!0,N.preventDefault()},b=N=>{O(c.current,N)&&E&&(c.current.removeEventListener("mousemove",w,!1),c.current.removeEventListener("touchmove",w,{passive:!1}),c.current.removeEventListener("mouseup",b,!1),c.current.removeEventListener("mouseout",b,!1),c.current.removeEventListener("touchend",b,!1),E=!1,e.confirm&&e.confirm({x:parseInt(F.toString()),y:n.thumbY||0},()=>{m()}),N.cancelBubble=!0,N.preventDefault())};c.current.addEventListener("mousemove",w,!1),c.current.addEventListener("touchmove",w,{passive:!1}),c.current.addEventListener("mouseup",b,!1),c.current.addEventListener("mouseout",b,!1),c.current.addEventListener("touchend",b,!1)},[s,o,n.thumbX,n.thumbY,l,c,e,m]),S=i.useCallback(x=>(e&&e.close&&e.close(),m(),x.cancelBubble=!0,x.preventDefault(),!1),[m,e]),f=i.useCallback(x=>(e&&e.refresh&&e.refresh(),m(),x.cancelBubble=!0,x.preventDefault(),!1),[m,e]),D=i.useCallback(()=>({x:h,y:n.thumbY||0}),[n.thumbY,h]);return{getState:i.useCallback(()=>({dragLeft:a,thumbLeft:h}),[h,a]),getPoint:D,dragEvent:C,closeEvent:S,refreshEvent:f}},ae=n=>{const e={...ie(),...n.config||{}},o=i.useRef(null),l=i.useRef(null),s=i.useRef(null),c=i.useRef(null),a=n.data||{},r=se(a,n.events||{},l,c,s,o),h=e.horizontalPadding||0,u=e.verticalPadding||0,m=(e.width||0)+u*2;return t.createElement("div",{className:T(d.wrapper,e.showTheme&&d.theme),style:{width:m+"px",paddingLeft:u+"px",paddingRight:u+"px",paddingTop:h+"px",paddingBottom:h+"px"}},t.createElement("div",{className:d.header},t.createElement("span",null,"请拖动滑块完成拼图"),t.createElement("div",{className:d.iconBlock},t.createElement($,{width:22,height:22,onClick:r.closeEvent}),t.createElement(M,{width:22,height:22,onClick:r.refreshEvent}))),t.createElement("div",{className:d.body,ref:l},t.createElement("div",{className:d.loading},t.createElement(K,null)),t.createElement("img",{className:d.picture,style:{width:e.width+"px",height:e.height+"px"},src:a.image,alt:"..."}),t.createElement("div",{className:le.tile,ref:c,style:{width:(a.thumbWidth||0)+"px",height:(a.thumbHeight||0)+"px",top:(a.thumbY||0)+"px",left:r.getState().thumbLeft+"px"}},t.createElement("img",{src:a.thumb,alt:"..."}))),t.createElement("div",{className:d.footer},t.createElement("div",{className:d.dragSlideBar,ref:o,onMouseDown:r.dragEvent},t.createElement("div",{className:d.dragLine}),t.createElement("div",{className:d.dragBlock,ref:s,onTouchStart:r.dragEvent,style:{left:r.getState().dragLeft+"px"}},t.createElement(q,null)))))};var re=t.memo(ae),de=`/**
 * @Author Awen
 * @Date 2024/05/25
 * @Email wengaolng@gmail.com
 **/
.index-module_header__jVeEs {
  text-align: center;
}
.index-module_tile__VR9Ut {
  position: absolute;
  z-index: 30;
  cursor: pointer;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.index-module_tile__VR9Ut img {
  display: block;
  cursor: pointer;
  width: 100%;
  height: 100%;
}
`,W={header:"index-module_header__jVeEs",tile:"index-module_tile__VR9Ut"};A(de);const ue=()=>({width:300,height:240,verticalPadding:16,horizontalPadding:12,showTheme:!0}),me=(n,e,o,l)=>{const[s,c]=i.useState({x:n.thumbX||0,y:n.thumbY||0}),a=i.useCallback(()=>{c({x:n.thumbX||0,y:n.thumbY||0})},[n.thumbX,n.thumbY]),r=i.useCallback(m=>{const C=m.touches&&m.touches[0],S=l.current.offsetLeft,f=l.current.offsetTop,D=o.current.offsetWidth,X=o.current.offsetHeight,x=l.current.offsetWidth,P=l.current.offsetHeight,y=D-x,z=X-P;let v=!1,_=0,k=0,B=0,L=0;C?(_=C.pageX-S,k=C.pageY-f):(_=m.clientX-S,k=m.clientY-f);const g=p=>{v=!0;const F=p.touches&&p.touches[0];let w=0,b=0;F?(w=F.pageX-_,b=F.pageY-k):(w=p.clientX-_,b=p.clientY-k),w<=0&&(w=0),b<=0&&(b=0),w>=y&&(w=y),b>=z&&(b=z),c({x:w,y:b}),B=w,L=b,e.move&&e.move(w,b),p.cancelBubble=!0,p.preventDefault()},E=p=>{O(o.current,p)&&v&&(v=!1,o.current.removeEventListener("mousemove",g,!1),o.current.removeEventListener("touchmove",g,{passive:!1}),o.current.removeEventListener("mouseup",E,!1),o.current.removeEventListener("mouseout",E,!1),o.current.removeEventListener("touchend",E,!1),e.confirm&&e.confirm({x:B,y:L},()=>{a()}),p.cancelBubble=!0,p.preventDefault())};o.current.addEventListener("mousemove",g,!1),o.current.addEventListener("touchmove",g,{passive:!1}),o.current.addEventListener("mouseup",E,!1),o.current.addEventListener("mouseout",E,!1),o.current.addEventListener("touchend",E,!1)},[o,l,e,a]),h=i.useCallback(m=>(e&&e.close&&e.close(),a(),m.cancelBubble=!0,m.preventDefault(),!1),[a,e]),u=i.useCallback(m=>(e&&e.refresh&&e.refresh(),a(),m.cancelBubble=!0,m.preventDefault(),!1),[a,e]);return{thumbPoint:s,dragEvent:r,closeEvent:h,refreshEvent:u}},he=n=>{const e={...ue(),...n.config||{}},o=i.useRef(null),l=i.useRef(null),s=n.data||{},c=me(s,n.events||{},o,l),a=e.horizontalPadding||0,r=e.verticalPadding||0,h=(e.width||0)+r*2;return i.useEffect(()=>{l.current.addEventListener("dragstart",u=>u.preventDefault())},[l]),t.createElement("div",{className:T(d.wrapper,W.wrapper,e.showTheme&&d.theme),style:{width:h+"px",paddingLeft:r+"px",paddingRight:r+"px",paddingTop:a+"px",paddingBottom:a+"px"}},t.createElement("div",{className:T(d.header,W.header)},t.createElement("span",null,"请拖动滑块完成拼图")),t.createElement("div",{className:d.body,ref:o},t.createElement("div",{className:d.loading},t.createElement(K,null)),t.createElement("img",{className:d.picture,src:s.image,alt:"..."}),t.createElement("div",{className:W.tile,ref:l,style:{width:(s.thumbWidth||0)+"px",height:(s.thumbHeight||0)+"px",top:c.thumbPoint.y+"px",left:c.thumbPoint.x+"px"},onMouseDown:c.dragEvent,onTouchStart:c.dragEvent},t.createElement("img",{src:s.thumb,alt:"..."}))),t.createElement("div",{className:d.footer},t.createElement("div",{className:d.iconBlock},t.createElement($,{width:20,height:20,onClick:c.closeEvent}),t.createElement(M,{width:20,height:20,onClick:c.refreshEvent}))))};var pe=t.memo(he),fe=`/**
 * @Author Awen
 * @Date 2024/05/25
 * @Email wengaolng@gmail.com
 **/
.index-module_body__5eTaZ {
  background: transparent !important;
  display: flex;
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  justify-content: center;
  align-items: center;
}
.index-module_picture__M-qbX {
  position: relative;
  max-width: 100%;
  max-height: 100%;
  z-index: 10;
  border-radius: 100%;
  overflow: hidden;
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  justify-content: center;
  align-items: center;
}
.index-module_picture__M-qbX img {
  max-width: 100%;
  max-height: 100%;
}
.index-module_round__zaOPS {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-radius: 100%;
  z-index: 20;
  border: 6px solid #e0e0e0;
}
.index-module_thumb__jChIh {
  position: absolute;
  z-index: 30;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
}
.index-module_thumb__jChIh img {
  max-width: 100%;
  max-height: 100%;
}
.index-module_thumbBlock__u3U1X {
  width: 100%;
  height: 100%;
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  justify-content: center;
  align-items: center;
}
`,j={body:"index-module_body__5eTaZ",picture:"index-module_picture__M-qbX",round:"index-module_round__zaOPS",thumb:"index-module_thumb__jChIh",thumbBlock:"index-module_thumbBlock__u3U1X"};A(fe);const ge=()=>({width:300,height:240,size:240,verticalPadding:16,horizontalPadding:12,showTheme:!0}),be=(n,e,o,l)=>{const[s,c]=i.useState(0),[a,r]=i.useState(n.angle||0),h=i.useCallback(()=>{c(0),r(0)},[]),u=i.useCallback(f=>{const D=f.touches&&f.touches[0],X=o.current.offsetLeft,x=l.current.offsetWidth,P=o.current.offsetWidth,y=x-P,z=360/y;let v=0,_=!1,k=0;D?k=D.pageX-X:k=f.clientX-X;const B=g=>{_=!0;const E=g.touches&&g.touches[0];let p=0;if(E?p=E.pageX-k:p=g.clientX-k,p>=y){c(y);return}if(p<=0){c(0);return}c(p),v=p*z,r(v),e.rotate&&e.rotate(v),g.cancelBubble=!0,g.preventDefault()},L=g=>{O(l.current,g)&&_&&(l.current.removeEventListener("mousemove",B,!1),l.current.removeEventListener("touchmove",B,{passive:!1}),l.current.removeEventListener("mouseup",L,!1),l.current.removeEventListener("mouseout",L,!1),l.current.removeEventListener("touchend",L,!1),_=!1,e.confirm&&e.confirm(parseInt(v.toString()),()=>{h()}),g.cancelBubble=!0,g.preventDefault())};l.current.addEventListener("mousemove",B,!1),l.current.addEventListener("touchmove",B,{passive:!1}),l.current.addEventListener("mouseup",L,!1),l.current.addEventListener("mouseout",L,!1),l.current.addEventListener("touchend",L,!1)},[o,l,e,h]),m=i.useCallback(f=>(e&&e.close&&e.close(),h(),f.cancelBubble=!0,f.preventDefault(),!1),[h,e]),C=i.useCallback(f=>(e&&e.refresh&&e.refresh(),h(),f.cancelBubble=!0,f.preventDefault(),!1),[h,e]);return{getState:i.useCallback(()=>({dragLeft:s,thumbAngle:a}),[a,s]),thumbAngle:a,dragEvent:u,closeEvent:m,refreshEvent:C}},xe=n=>{const e={...ge(),...n.config||{}},o=i.useRef(null),l=i.useRef(null),s=n.data||{},c=be(s,n.events||{},l,o),a=e.horizontalPadding||0,r=e.verticalPadding||0,h=(e.width||0)+r*2;return t.createElement("div",{className:T(d.wrapper,j.wrapper,e.showTheme&&d.theme),style:{width:h+"px",paddingLeft:r+"px",paddingRight:r+"px",paddingTop:a+"px",paddingBottom:a+"px"}},t.createElement("div",{className:d.header},t.createElement("span",null,"请拖动滑块完成拼图"),t.createElement("div",{className:d.iconBlock},t.createElement($,{width:22,height:22,onClick:c.closeEvent}),t.createElement(M,{width:22,height:22,onClick:c.refreshEvent}))),t.createElement("div",{className:T(d.body,j.body)},t.createElement("div",{className:d.loading},t.createElement(K,null)),t.createElement("div",{className:j.picture,style:{width:e.size+"px",height:e.size+"px"}},t.createElement("img",{src:s.image,alt:"..."}),t.createElement("div",{className:j.round})),t.createElement("div",{className:j.thumb},t.createElement("div",{className:j.thumbBlock,style:{transform:"rotate("+c.getState().thumbAngle+"deg)"}},t.createElement("img",{src:s.thumb,alt:"..."})))),t.createElement("div",{className:d.footer},t.createElement("div",{className:d.dragSlideBar,ref:o,onMouseDown:c.dragEvent},t.createElement("div",{className:d.dragLine}),t.createElement("div",{className:d.dragBlock,ref:l,onTouchStart:c.dragEvent,style:{left:c.getState().dragLeft+"px"}},t.createElement(q,null)))))};var _e=t.memo(xe);const we=()=>({width:330,height:44,verticalPadding:12,horizontalPadding:16});var ve=`/**
 * @Author Awen
 * @Date 2024/05/25
 * @Email wengaolng@gmail.com
 **/
.index-module_btnBlock__L96Vx {
  position: relative;
  box-sizing: border-box;
  display: block;
  font-size: 13px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  letter-spacing: 1px;
  border-radius: 5px;
  line-height: 1;
  white-space: nowrap;
  -webkit-appearance: none;
  outline: none;
  margin: 0;
  transition: 0.1s;
  font-weight: 500;
  -moz-user-select: none;
  -webkit-user-select: none;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  justify-content: center;
  justify-items: center;
  box-shadow: 0 0 20px rgba(62, 124, 255, 0.1);
  -webkit-box-shadow: 0 0 20px rgba(62, 124, 255, 0.1);
  -moz-box-shadow: 0 0 20px rgba(62, 124, 255, 0.1);
}
.index-module_btnBlock__L96Vx span {
  padding-left: 8px;
}
.index-module_disabled__U5sNo {
  pointer-events: none;
}
.index-module_default__r2sQq {
  color: #3e7cff;
  border: 1px solid #50a1ff;
  background: #ecf5ff;
  cursor: pointer;
}
.index-module_default__r2sQq:hover {
  background: #e0efff !important;
}
.index-module_error__mCm6a {
  cursor: pointer;
  color: #ed4630;
  background: #fef0f0;
  border: 1px solid #ff5a34;
}
.index-module_warn__CT1sW {
  cursor: pointer;
  color: #ffa000;
  background: #fdf6ec;
  border: 1px solid #ffbe09;
}
.index-module_success__61kOU {
  color: #5eaa2f;
  background: #f0f9eb;
  border: 1px solid #8bc640;
  pointer-events: none;
}
.index-module_ripple__KF4IK {
  position: relative;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  justify-content: center;
  justify-items: center;
}
.index-module_ripple__KF4IK::after {
  background: #409eff;
  -webkit-border-radius: 50px;
  -moz-border-radius: 50px;
  border-radius: 50px;
  content: "";
  display: block;
  width: 20px;
  height: 20px;
  opacity: 0;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 9;
  animation: index-module_ripple__KF4IK 1.3s infinite;
  -moz-animation: index-module_ripple__KF4IK 1.3s infinite;
  -webkit-animation: index-module_ripple__KF4IK 1.3s infinite;
  animation-delay: 2s;
  -moz-animation-delay: 2s;
  -webkit-animation-delay: 2s;
}
@keyframes index-module_ripple__KF4IK {
  0% {
    opacity: 0;
  }
  5% {
    opacity: 0.05;
  }
  20% {
    opacity: 0.35;
  }
  65% {
    opacity: 0.01;
  }
  100% {
    transform: scaleX(2) scaleY(2);
    opacity: 0;
  }
}
@-webkit-keyframes index-module_ripple__KF4IK {
  0% {
    opacity: 0;
  }
  5% {
    opacity: 0.05;
  }
  20% {
    opacity: 0.35;
  }
  65% {
    opacity: 0.01;
  }
  100% {
    transform: scaleX(2) scaleY(2);
    opacity: 0;
  }
}
`,Y={btnBlock:"index-module_btnBlock__L96Vx",disabled:"index-module_disabled__U5sNo",default:"index-module_default__r2sQq",error:"index-module_error__mCm6a",warn:"index-module_warn__CT1sW",success:"index-module_success__61kOU",ripple:"index-module_ripple__KF4IK"};A(ve);const Ee=n=>i.createElement("svg",Object.assign({viewBox:"0 0 200 200",xmlns:"http://www.w3.org/2000/svg",width:20,height:20},n),i.createElement("circle",{fill:"#3E7CFF",cx:"100",cy:"100",r:"96.3"}),i.createElement("path",{fill:"#FFFFFF",d:`M140.8,64.4l-39.6-11.9h-2.4L59.2,64.4c-1.6,0.8-2.8,2.4-2.8,4v24.1c0,25.3,15.8,45.9,42.3,54.6
	c0.4,0,0.8,0.4,1.2,0.4c0.4,0,0.8,0,1.2-0.4c26.5-8.7,42.3-28.9,42.3-54.6V68.3C143.5,66.8,142.3,65.2,140.8,64.4z`})),ye=n=>i.createElement("svg",Object.assign({viewBox:"0 0 200 200",xmlns:"http://www.w3.org/2000/svg",width:20,height:20},n),i.createElement("path",{fill:"#ED4630",d:`M184,26.6L102.4,2.1h-4.9L16,26.6c-3.3,1.6-5.7,4.9-5.7,8.2v49.8c0,52.2,32.6,94.7,87.3,112.6
	c0.8,0,1.6,0.8,2.4,0.8s1.6,0,2.4-0.8c54.7-18,87.3-59.6,87.3-112.6V34.7C189.8,31.5,187.3,28.2,184,26.6z M134.5,123.1
	c3.1,3.1,3.1,8.2,0,11.3c-1.6,1.6-3.6,2.3-5.7,2.3s-4.1-0.8-5.7-2.3L100,111.3l-23.1,23.1c-1.6,1.6-3.6,2.3-5.7,2.3
	c-2,0-4.1-0.8-5.7-2.3c-3.1-3.1-3.1-8.2,0-11.3L88.7,100L65.5,76.9c-3.1-3.1-3.1-8.2,0-11.3c3.1-3.1,8.2-3.1,11.3,0L100,88.7
	l23.1-23.1c3.1-3.1,8.2-3.1,11.3,0c3.1,3.1,3.1,8.2,0,11.3L111.3,100L134.5,123.1z`})),ke=n=>i.createElement("svg",Object.assign({viewBox:"0 0 200 200",xmlns:"http://www.w3.org/2000/svg",width:20,height:20},n),i.createElement("path",{fill:"#FFA000",d:`M184,26.6L102.4,2.1h-4.9L16,26.6c-3.3,1.6-5.7,4.9-5.7,8.2v49.8c0,52.2,32.6,94.7,87.3,112.6
	c0.8,0,1.6,0.8,2.4,0.8s1.6,0,2.4-0.8c54.7-18,87.3-59.6,87.3-112.6V34.7C189.8,31.5,187.3,28.2,184,26.6z M107.3,109.1
	c-0.5,5.4-3.9,7.9-7.3,7.9c-2.5,0,0,0,0,0c-3.2-0.6-5.7-2-6.8-7.4l-4.4-50.9c0-5.1,6.2-9.7,11.5-9.7c5.3,0,11,4.7,11,9.9
	L107.3,109.1z M109.3,133.3c0,5.1-4.2,9.3-9.3,9.3c-5.1,0-9.3-4.2-9.3-9.3c0-5.1,4.2-9.3,9.3-9.3C105.1,124,109.3,128.1,109.3,133.3
	z`})),Le=n=>i.createElement("svg",Object.assign({viewBox:"0 0 200 200",xmlns:"http://www.w3.org/2000/svg",width:20,height:20},n),i.createElement("path",{fill:"#5EAA2F",d:`M183.3,27.2L102.4,2.9h-4.9L16.7,27.2C13.4,28.8,11,32,11,35.3v49.4c0,51.8,32.4,93.9,86.6,111.7
	c0.8,0,1.6,0.8,2.4,0.8c0.8,0,1.6,0,2.4-0.8c54.2-17.8,86.6-59.1,86.6-111.7V35.3C189,32,186.6,28.8,183.3,27.2z M146.1,81.4
	l-48.5,48.5c-1.6,1.6-3.2,2.4-5.7,2.4c-2.4,0-4-0.8-5.7-2.4L62,105.7c-3.2-3.2-3.2-8.1,0-11.3c3.2-3.2,8.1-3.2,11.3,0l18.6,18.6
	l42.9-42.9c3.2-3.2,8.1-3.2,11.3,0C149.4,73.3,149.4,78.2,146.1,81.4L146.1,81.4z`})),Ce=n=>{const e={...we(),...n.config||{}},o=n.type||"default";let l=t.createElement(Ee,null),s=Y.default;return o=="warn"?(l=t.createElement(ke,null),s=Y.warn):o=="error"?(l=t.createElement(ye,null),s=Y.error):o=="success"&&(l=t.createElement(Le,null),s=Y.success),t.createElement("div",{className:T(Y.btnBlock,s,n.disabled&&Y.disabled),style:{width:e.width+"px",height:e.height+"px",paddingLeft:e.verticalPadding+"px",paddingRight:e.verticalPadding+"px",paddingTop:e.verticalPadding+"px",paddingBottom:e.verticalPadding+"px"},onClick:n.clickEvent},o=="default"?t.createElement("div",{className:Y.ripple},l):l,t.createElement("span",null,n.title||"点击按键进行验证"))};var ze=t.memo(Ce),De={Click:oe,Slide:re,SlideRegion:pe,Rotate:_e,Button:ze};export{De as G};
