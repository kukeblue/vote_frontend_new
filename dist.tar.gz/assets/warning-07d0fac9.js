var r,n;function i(){if(n)return r;n=1;var a=function(){};return r=a,r}export{i as r};
