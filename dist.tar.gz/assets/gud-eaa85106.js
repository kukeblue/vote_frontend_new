import{p as e}from"./@babel-591e9e4c.js";var r,n;function a(){if(n)return r;n=1;var u="__global_unique_id__";return r=function(){return e[u]=(e[u]||0)+1},r}export{a as r};
