import{r as o,a as y}from"./react-5372a523.js";import{R as v,u as b,a as P}from"./react-router-bca5c0f8.js";import{c as T}from"./@remix-run-7c975f36.js";/**
 * React Router DOM v6.14.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */function f(e){return e===void 0&&(e=""),new URLSearchParams(typeof e=="string"||Array.isArray(e)||e instanceof URLSearchParams?e:Object.keys(e).reduce((a,r)=>{let t=e[r];return a.concat(Array.isArray(t)?t.map(s=>[r,s]):[[r,t]])},[]))}function U(e,a){let r=f(e);if(a)for(let t of a.keys())r.has(t)||a.getAll(t).forEach(s=>{r.append(t,s)});return r}const g="startTransition",S=y[g];function w(e){let{basename:a,children:r,future:t,window:s}=e,n=o.useRef();n.current==null&&(n.current=T({window:s,v5Compat:!0}));let c=n.current,[u,l]=o.useState({action:c.action,location:c.location}),{v7_startTransition:i}=t||{},m=o.useCallback(h=>{i&&S?S(()=>l(h)):l(h)},[l,i]);return o.useLayoutEffect(()=>c.listen(m),[c,m]),o.createElement(v,{basename:a,children:r,location:u.location,navigationType:u.action,navigator:c})}var R;(function(e){e.UseScrollRestoration="useScrollRestoration",e.UseSubmit="useSubmit",e.UseSubmitFetcher="useSubmitFetcher",e.UseFetcher="useFetcher"})(R||(R={}));var p;(function(e){e.UseFetchers="useFetchers",e.UseScrollRestoration="useScrollRestoration"})(p||(p={}));function L(e){let a=o.useRef(f(e)),r=o.useRef(!1),t=b(),s=o.useMemo(()=>U(t.search,r.current?null:a.current),[t.search]),n=P(),c=o.useCallback((u,l)=>{const i=f(typeof u=="function"?u(s):u);r.current=!0,n("?"+i,l)},[n,s]);return[s,c]}export{w as B,L as u};
